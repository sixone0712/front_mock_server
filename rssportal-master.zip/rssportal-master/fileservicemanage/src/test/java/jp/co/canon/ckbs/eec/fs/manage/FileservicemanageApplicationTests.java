package jp.co.canon.ckbs.eec.fs.manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileservicemanageApplicationTests {

	@Test
	void contextLoads() {
	}

}
