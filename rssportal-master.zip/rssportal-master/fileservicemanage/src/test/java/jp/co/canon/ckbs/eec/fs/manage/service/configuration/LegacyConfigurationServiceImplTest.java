package jp.co.canon.ckbs.eec.fs.manage.service.configuration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class LegacyConfigurationServiceImplTest {
    @Test
    void test_001(){

    }
}
