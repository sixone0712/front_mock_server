package jp.co.canon.ckbs.eec.fs.manage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileservicemanageApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileservicemanageApplication.class, args);
	}

}
