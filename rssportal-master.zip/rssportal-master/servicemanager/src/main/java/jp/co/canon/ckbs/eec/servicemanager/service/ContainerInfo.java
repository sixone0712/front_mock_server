package jp.co.canon.ckbs.eec.servicemanager.service;

import lombok.Getter;
import lombok.Setter;

public class ContainerInfo {
    @Getter @Setter
    String name;

    @Getter @Setter
    String status;
}
