package jp.co.canon.ckbs.eec.servicemanager.service;

import lombok.Getter;
import lombok.Setter;

public class LogFileList {
    @Getter @Setter
    LogFileInfo[] list;
}
