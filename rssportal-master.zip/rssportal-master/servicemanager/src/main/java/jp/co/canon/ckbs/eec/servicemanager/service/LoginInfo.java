package jp.co.canon.ckbs.eec.servicemanager.service;

import lombok.Getter;
import lombok.Setter;

public class LoginInfo {
    @Getter @Setter
    String id;
    @Getter @Setter
    String password;
}
