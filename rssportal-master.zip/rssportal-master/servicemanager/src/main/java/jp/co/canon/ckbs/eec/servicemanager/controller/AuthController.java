package jp.co.canon.ckbs.eec.servicemanager.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import jp.co.canon.ckbs.eec.servicemanager.session.SessionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final HttpSession httpSession;

    @Value("${servicemanager.admin-init-password}")
    private String adminInitPassword;

    @Value("${servicemanager.admin-init-password-filename}")
    private String adminInitPasswordFilename;

    @Autowired
    public AuthController(HttpSession httpSession) {
        this.httpSession = httpSession;
    }

    @GetMapping("/me")
    @ResponseBody
    public ResponseEntity<?> isLogin(HttpServletRequest request)  throws Exception {
        if(httpSession.getAttribute("context") != null) {
            SessionContext context = (SessionContext)httpSession.getAttribute("context");
            if(context.isAuthenticated()) {
                return ResponseEntity.status(HttpStatus.OK).body(null);
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
    }

    @GetMapping("/login")
    @ResponseBody
    public ResponseEntity<?> Login(HttpServletRequest request,
        @RequestParam(name="password", required = false, defaultValue = "") String password)  throws Exception {

        if(password == null || password.equals("")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        String adminPassword = "";
        try {
            Gson gsonRead = new Gson();
            JsonReader jsonReader = new JsonReader(new FileReader(adminInitPasswordFilename));
            HashMap<String, String> admin = gsonRead.fromJson(jsonReader, HashMap.class);
            adminPassword = admin.get("Administrator");
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(!password.equals(adminPassword)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        SessionContext context = new SessionContext();
        context.setAuthenticated(true);
        httpSession.setAttribute("context", context);
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

    @GetMapping("/logout")
    @ResponseBody
    public ResponseEntity<?> Login(HttpServletRequest request)  throws Exception {
        this.httpSession.invalidate();
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }
}
