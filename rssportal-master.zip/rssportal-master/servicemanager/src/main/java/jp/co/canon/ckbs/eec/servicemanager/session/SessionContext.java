package jp.co.canon.ckbs.eec.servicemanager.session;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SessionContext {
    private boolean authenticated = false;
}


