package jp.co.canon.ckbs.eec.servicemanager.controller;

import lombok.Getter;
import lombok.Setter;

public class RestartResponse {
    @Getter @Setter
    ErrorInfo error;
}
