package jp.co.canon.ckbs.eec.servicemanager.service;

import org.junit.jupiter.api.Test;

public class ConfigLoaderTest {
}
