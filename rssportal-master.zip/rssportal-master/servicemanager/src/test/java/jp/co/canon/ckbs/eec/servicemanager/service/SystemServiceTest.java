package jp.co.canon.ckbs.eec.servicemanager.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SystemServiceTest {
    @Autowired
    SystemService systemService;

    @Test
    void test_001(){
        System.out.println("Start Test");
        System.out.println("End Test");
    }
}
