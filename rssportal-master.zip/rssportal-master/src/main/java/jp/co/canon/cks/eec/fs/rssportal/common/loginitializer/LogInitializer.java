package jp.co.canon.cks.eec.fs.rssportal.common.loginitializer;

public interface LogInitializer {

    String getLogType();
    String getPattern();
    String getFileName();
}
