package jp.co.canon.cks.eec.fs.rssportal.Defines;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RestApiCategory {
	String categoryCode;
	String categoryName;
}
