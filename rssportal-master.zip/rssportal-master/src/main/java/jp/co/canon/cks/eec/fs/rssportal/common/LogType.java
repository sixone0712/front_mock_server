package jp.co.canon.cks.eec.fs.rssportal.common;

public enum LogType {
    user,
    control,
    download,
    subsystem,
    exception
}
