package jp.co.canon.cks.eec.fs.rssportal.background;

public enum JobType {
    manual, plan
}
