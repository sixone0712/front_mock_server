package jp.co.canon.cks.eec.fs.rssportal.background;

public enum CollectType {
    ftp,
    vftp_compat,
    vftp_sss
}
