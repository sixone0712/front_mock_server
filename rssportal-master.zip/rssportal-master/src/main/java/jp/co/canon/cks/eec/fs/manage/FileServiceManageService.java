/**
 * FileServiceManageService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package jp.co.canon.cks.eec.fs.manage;

public interface FileServiceManageService extends javax.xml.rpc.Service {
    public java.lang.String getFileServiceManageAddress();

    public jp.co.canon.cks.eec.fs.manage.FileServiceManage getFileServiceManage() throws javax.xml.rpc.ServiceException;

    public jp.co.canon.cks.eec.fs.manage.FileServiceManage getFileServiceManage(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
