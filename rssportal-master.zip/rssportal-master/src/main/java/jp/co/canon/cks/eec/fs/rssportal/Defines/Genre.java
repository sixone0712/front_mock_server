
package jp.co.canon.cks.eec.fs.rssportal.Defines;

import java.util.List;

public class Genre {
    public String dispName;
    public String keyName;
    public List<Integer> machine;
    public List<Integer> fileCat;
}