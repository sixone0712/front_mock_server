package jp.co.canon.ckbs.eec.fs.collect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileServiceCollectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileServiceCollectApplication.class, args);
	}

}
