package jp.co.canon.ckbs.eec.fs.collect.executor;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.exec.*;

import java.io.IOException;

@Slf4j
public class CustomExecutor {
    ExecuteWatchdog watchdog = new ExecuteWatchdog(ExecuteWatchdog.INFINITE_TIMEOUT);
    boolean started = false;

    public int execute(CommandLine cmdLine, CustomOutputStreamLineHandler streamLineHandler){
        log.info("execute command : {}", cmdLine.toString());
        DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
        DefaultExecutor executor = new DefaultExecutor();
        executor.setWatchdog(watchdog);
        CustemExecuteStreamHandler streamHandler = new CustemExecuteStreamHandler();
        streamHandler.setOutputStreamLineHandler(streamLineHandler);
        executor.setStreamHandler(streamHandler);

        try {
            executor.execute(cmdLine, resultHandler);
        } catch (IOException e) {
            log.error("failed to execute command({}), with exception({})", cmdLine.toString(), e.getMessage());
            return -1;
        }

        synchronized (this) {
            started = true;
        }

        try {
            resultHandler.waitFor();
        } catch (InterruptedException e) {
            log.error("interruped exception occurred({}) while wait process end.", e.getMessage());
            return -1;
        }

        try {
            streamHandler.join();
        } catch (InterruptedException e) {
            log.error("interruped exception occurred({}) while stream handler end.", e.getMessage());
            return -1;
        }
        started = false;
        return resultHandler.getExitValue();
    }

    public void stop(){
        synchronized (this) {
            log.trace("stop executor :{}", this);
            if (started) {
                watchdog.destroyProcess();
                started = false;
            }
        }
    }
}
