package jp.co.canon.ckbs.eec.fs.collect.service.vftp;

import jp.co.canon.ckbs.eec.fs.collect.model.VFtpSssDownloadRequest;
import org.junit.jupiter.api.Test;

public class SssDownloadProcessThreadTest {
    @Test
    void test_001(){
        VFtpSssDownloadRequest request = new VFtpSssDownloadRequest();
    }
}
