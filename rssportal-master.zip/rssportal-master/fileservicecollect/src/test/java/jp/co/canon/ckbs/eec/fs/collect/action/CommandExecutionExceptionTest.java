package jp.co.canon.ckbs.eec.fs.collect.action;

import org.junit.jupiter.api.Test;

public class CommandExecutionExceptionTest {
    @Test
    void test_001(){
        CommandExecutionException ex = new CommandExecutionException("E-500:Error");
        ex.getErrorCode();
    }
}
