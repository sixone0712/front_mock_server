package jp.co.canon.ckbs.eec.fs.collect.action;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;

@SpringBootTest
public class FtpDownloadFileRepositoryTest {
    @Autowired
    FtpDownloadFileRepository repository;

}
