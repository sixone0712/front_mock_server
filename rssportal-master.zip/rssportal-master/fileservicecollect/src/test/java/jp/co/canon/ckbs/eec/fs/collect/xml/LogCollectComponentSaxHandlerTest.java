package jp.co.canon.ckbs.eec.fs.collect.xml;

import org.junit.jupiter.api.Test;

public class LogCollectComponentSaxHandlerTest {
    @Test
    void test_001(){
        LogCollectComponentSaxHandler handler = new LogCollectComponentSaxHandler();

        handler.getName();
        handler.getDescription();
        handler.getSearchType();
    }
}
