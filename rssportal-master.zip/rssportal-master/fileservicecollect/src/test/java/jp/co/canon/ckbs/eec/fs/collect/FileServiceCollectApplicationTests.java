package jp.co.canon.ckbs.eec.fs.collect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileServiceCollectApplicationTests {

	@Test
	void contextLoads() {
//		String dir = System.getProperty("user.dir");
//		System.out.println(dir);
	}

}
