package jp.co.canon.ckbs.eec.fs.collect.action;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ConfigurationExceptionTest {
    @Test
    void test_001(){
        ConfigurationException ex = new ConfigurationException("msg", "001");
        Assertions.assertEquals("001", ex.getCode());
    }
}
