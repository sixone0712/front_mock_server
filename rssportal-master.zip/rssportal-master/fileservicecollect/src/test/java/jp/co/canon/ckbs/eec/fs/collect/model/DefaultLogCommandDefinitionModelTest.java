package jp.co.canon.ckbs.eec.fs.collect.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class DefaultLogCommandDefinitionModelTest {
    @Test
    void test_001(){
        DefaultLogCommandDefinitionModel model = new DefaultLogCommandDefinitionModel();

        model.setCommandCA("AAAA");
        Assertions.assertEquals("AAAA", model.getCommandCA());

        model.setLogId("003");
        Assertions.assertEquals("003", model.getLogId());
    }
}
