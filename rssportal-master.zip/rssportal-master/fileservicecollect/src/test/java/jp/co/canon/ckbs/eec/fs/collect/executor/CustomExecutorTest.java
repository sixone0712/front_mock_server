package jp.co.canon.ckbs.eec.fs.collect.executor;

import org.apache.commons.exec.CommandLine;
import org.junit.jupiter.api.Test;

public class CustomExecutorTest {

    @Test
    void test_001() {
        CustomExecutor executor = new CustomExecutor();
        CommandLine commandLine = new CommandLine("java");
        commandLine.addArgument("-cp");
        commandLine.addArgument("/root/Libs/ELogCollector.jar");
        commandLine.addArgument("jp.co.canon.ckbs.eec.service.FtpCommand");
        commandLine.addArgument("list");

        executor.execute(commandLine, new CustomOutputStreamLineHandler() {
            @Override
            public boolean processOutputLine(String line) {
                executor.stop();
                return true;
            }

            @Override
            public boolean processErrorLine(String line) {
                executor.stop();
                return true;
            }
        });

        executor.stop();
    }

    @Test
    void test_002() {
        CustomExecutor executor = new CustomExecutor();
        CommandLine commandLine = new CommandLine("java");
        commandLine.addArgument("-cp");
        commandLine.addArgument("/root/Libs/ELogCollector.jar");
        commandLine.addArgument("jp.co.canon.ckbs.eec.service.FtpCommand");
        commandLine.addArgument("list");

        executor.execute(commandLine, new CustomOutputStreamLineHandler() {
            @Override
            public boolean processOutputLine(String line) {
                return false;
            }

            @Override
            public boolean processErrorLine(String line) {
                return true;
            }
        });
    }

    @Test
    void test_003() {
        CustomExecutor executor = new CustomExecutor();
        CommandLine commandLine = new CommandLine("java");
        commandLine.addArgument("-cp");
        commandLine.addArgument("/root/Libs/ELogCollector.jar");
        commandLine.addArgument("jp.co.canon.ckbs.eec.service.FtpCommand");
        commandLine.addArgument("list");

        executor.execute(commandLine, new CustomOutputStreamLineHandler() {
            @Override
            public boolean processOutputLine(String line) {
                return true;
            }

            @Override
            public boolean processErrorLine(String line) {
                return false;
            }
        });
    }
}
