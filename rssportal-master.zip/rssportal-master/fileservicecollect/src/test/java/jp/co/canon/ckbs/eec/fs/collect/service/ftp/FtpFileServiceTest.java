package jp.co.canon.ckbs.eec.fs.collect.service.ftp;

import jp.co.canon.ckbs.eec.fs.collect.service.ftp.FtpFileService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FtpFileServiceTest {
    @Autowired
    FtpFileService fileService;

    @Test
    void test_001_001(){
        fileService.getLogFileList(null, null, null, null, null, null);

        fileService.getLogFileList("MPA_AAA", null, null, null, null, null);
    }

    @Test
    void test_002_001(){
        fileService.getLogFileList("MPA_AAA", "002", "20200825000000", "20200825120000", "", null);
    }
}
