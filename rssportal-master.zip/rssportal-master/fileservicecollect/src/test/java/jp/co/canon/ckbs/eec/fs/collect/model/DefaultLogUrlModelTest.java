package jp.co.canon.ckbs.eec.fs.collect.model;

import org.junit.jupiter.api.Test;

public class DefaultLogUrlModelTest {
    @Test
    void test_001(){
        DefaultLogUrlModel model = new DefaultLogUrlModel();

        model.setFtpmode(null);

        model.setFtpmode("active");

        model.setFtpmode("none");
    }
}
