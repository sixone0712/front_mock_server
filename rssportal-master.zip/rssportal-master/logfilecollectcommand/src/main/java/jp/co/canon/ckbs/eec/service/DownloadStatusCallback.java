package jp.co.canon.ckbs.eec.service;

public interface DownloadStatusCallback {
    void downloadStart(String fileName);
    void downloadProgress(String fileName, long fileSize, long totalDownloadSize);
    void downloadCompleted(String fileName, long fileSize, long totalDownloadSize, String destFilePath);
    void archiveCompleted(String archiveFileName, long fileSize);
}
