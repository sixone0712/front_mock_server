package jp.co.canon.ckbs.eec.service.command;

public class LocalFileAccessor extends FileAccessor{
    @Override
    FileConnection createFileConnection() {
        return new LocalFileConnection();
    }
}
