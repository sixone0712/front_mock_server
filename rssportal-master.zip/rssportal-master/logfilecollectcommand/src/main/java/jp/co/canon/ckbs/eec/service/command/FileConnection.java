package jp.co.canon.ckbs.eec.service.command;

import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;

abstract public class FileConnection {
    abstract public boolean connect(Configuration configuration);
    abstract public void disconnect();

    abstract public boolean changeDirectory(String directory);
    abstract public LogFileInfo[] listFiles();

    abstract public InputStream getInputStream(String fileName);

    abstract public void completePendingCommand();

    static Calendar toCalendar(long timestamp){
        Date date = new Date(timestamp);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }
}
