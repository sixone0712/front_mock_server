package jp.co.canon.ckbs.eec.service.command;

import jp.co.canon.ckbs.eec.service.*;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Slf4j
abstract public class FileAccessor {
    Configuration configuration;

    public void setConfiguration(Configuration configuration){
        this.configuration = configuration;
    }

    abstract FileConnection createFileConnection();

    static boolean checkDate(Calendar startDate, Calendar endDate, Calendar dateToCheck){
        if (startDate == null && endDate == null){
            return true;
        }
        long date = dateToCheck.getTimeInMillis();
        if (startDate != null && date < startDate.getTimeInMillis()){
            return false;
        }
        if (endDate != null && date > endDate.getTimeInMillis()){
            return false;
        }
        return true;
    }

    static String mergePath(String path, String str){
        if (str == null || str.length() == 0){
            return path;
        }
        if (path == null || path.length() == 0){
            return str;
        }
        if (str.startsWith("/")){
            return String.format("%s%s", path, str);
        }
        return String.format("%s/%s", path, str);
    }

    static class DirInfo {
        DirInfo(String path, int level){
            this.path = path;
            this.level = level;
        }

        String path;
        int level;
    }

    void listFiles_type1(ArrayList<LogFileInfo> logFileInfoArrayList,
                         RuleChecker ruleChecker,
                         Calendar startDate,
                         Calendar endDate,
                         String keyword
    ){
        String rootPath = configuration.rootPath;
        int matchLevel = ruleChecker.getCount() - 1;

        FileConnection connection = createFileConnection();

        boolean connected = connection.connect(configuration);
        if (connected == false){
            return;
        }
        Queue<DirInfo> directoriesToVisit = new LinkedList<>();

        directoriesToVisit.add(new DirInfo("", 0));
        DirInfo currentDirInfo = null;
        while((currentDirInfo = directoriesToVisit.poll()) != null){
            String pullPath = mergePath(rootPath, currentDirInfo.path);

            connection.changeDirectory(pullPath);

            LogFileInfo[] files = connection.listFiles();
            if (currentDirInfo.level == matchLevel){
                for (LogFileInfo file : files){
                    if (file.getIsFile()){
                        if (checkDate(startDate, endDate, file.getTimestamp())){
                            String name = file.getName();
                            if (ruleChecker.matches(name, currentDirInfo.level)){
                                String pullName = mergePath(currentDirInfo.path, name);
                                file.setName(pullName);
                                logFileInfoArrayList.add(file);
                            }
                        }
                    } else {
                        String name = file.getName();
                        if (ruleChecker.matches(name, currentDirInfo.level)){
                            String pullName = mergePath(currentDirInfo.path, name);
                            file.setName(pullName);
                            logFileInfoArrayList.add(file);
                        }
                    }
                }
            } else {
                for (LogFileInfo file : files){
                    if (!file.getIsFile()){
                        if (ruleChecker.matches(file.getName(), currentDirInfo.level)){
                            String newPath = mergePath(currentDirInfo.path, file.getName());
                            directoriesToVisit.add(new DirInfo(newPath, currentDirInfo.level+1));
                        }
                    }
                }
            }
        }

        connection.disconnect();
    }

    void listFiles_type2(ArrayList<LogFileInfo> logFileInfoArrayList,
                         RuleChecker ruleChecker,
                         Calendar startDate,
                         Calendar endDate,
                         String dir){
        String rootPath = configuration.rootPath;
        rootPath = mergePath(rootPath, dir);
        FileConnection connection = createFileConnection();

        boolean connected = connection.connect(configuration);
        if (connected == false){
            return;
        }
        connection.changeDirectory(rootPath);

        LogFileInfo[] files = connection.listFiles();
        for(LogFileInfo file : files){
            if (ruleChecker.matches(file.getName(), 0)){
                Calendar timestamp = file.getTimestamp();
                String name = mergePath(dir, file.getName());
                if (file.getIsFile()){
                    if (checkDate(startDate, endDate, timestamp)) {
                        file.setName(name);
                        logFileInfoArrayList.add(file);
                    }
                } else {
                    file.setName(name);
                    logFileInfoArrayList.add(file);
                }
            }
        }
    }

    public LogFileInfo[] listFiles(RuleChecker ruleChecker,
                                   Calendar startDate,
                                   Calendar endDate,
                                   String dir,
                                   String keyword){
        ArrayList<LogFileInfo> logFileInfoArrayList = new ArrayList<>();
        if (dir != null && dir.length() > 0){
            RuleChecker newRuleChecker = RuleChecker.create("*");
            listFiles_type2(logFileInfoArrayList, newRuleChecker, startDate, endDate, dir);
        } else {
            listFiles_type1(logFileInfoArrayList, ruleChecker, startDate, endDate, keyword);
        }
        return logFileInfoArrayList.toArray(new LogFileInfo[0]);
    }

    public boolean downloadFiles(FileInfoQueue fileInfoQueue,
                              String destDirStr,
                              boolean zip,
                              String zipFileName,
                              int maxThreadCount,
                              boolean preserveDirStructure,
                              StopChecker stopChecker,
                              DownloadStatusCallback callback){
        int threadCount = fileInfoQueue.size() < maxThreadCount ? fileInfoQueue.size() : maxThreadCount;
        log.info("Request File Count: {}, Total Thread Count : {}", fileInfoQueue.size(), threadCount);
        File destDir = new File(destDirStr);
        destDir.mkdirs();
        long downloadStartTime = System.currentTimeMillis();
        log.info("Download start at {}", downloadStartTime);
        DownloadInfo downloadInfo = new DownloadInfo();

        ArrayList<GetCommandExecuteThread> threadArrayList = new ArrayList<>();

        FileInfoQueue downloadedQueue = new FileInfoQueue();

        for(int idx = 0; idx < threadCount; ++idx){
            GetCommandExecuteThread getThread = new GetCommandExecuteThread(configuration,
                    this,
                    destDirStr,
                    fileInfoQueue,
                    preserveDirStructure,
                    downloadInfo,
                    downloadedQueue,
                    stopChecker,
                    callback);
            threadArrayList.add(getThread);
            getThread.start();
        }

        for(GetCommandExecuteThread th : threadArrayList){
            try {
                th.join();
            } catch(InterruptedException e){

            }
        }
        int errorCount = 0;
        for(GetCommandExecuteThread th : threadArrayList) {
            if (th.getExitWithError()){
                errorCount++;
            }
        }
        if (errorCount > 0){
            return false;
        }
        if (stopChecker.isStopped()){
            return false;
        }
        if (zip){
            long zipStartTime = System.currentTimeMillis();
            log.info("Zip Files Start at {}", zipStartTime);
            boolean zipSuccess = false;
            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(new File(destDir, zipFileName)))){
                FileInfo fileInfo = null;
                while((fileInfo = downloadedQueue.poll()) != null){
                    if (stopChecker.isStopped()){
                        throw new Exception("Stopped");
                    }
                    ZipEntry entry = new ZipEntry(fileInfo.getDownloadPath());
                    zos.putNextEntry(entry);
                    Files.copy(Paths.get(destDirStr, fileInfo.getDownloadPath()), zos);
                    zos.closeEntry();
                    File fileToDelete = new File(destDir, fileInfo.getDownloadPath());
                    fileToDelete.delete();
                }
                zipSuccess = true;
            } catch (Exception e){
                log.error("Exception :{}", e.getMessage());
                return false;
            }
            long zipEndTime = System.currentTimeMillis();
            log.info("Zip Files End at {}, zip spent time {}", zipEndTime, zipEndTime - zipStartTime);
            if (zipSuccess){
                File zipFile = new File(destDir, zipFileName);
                if(callback != null){
                    callback.archiveCompleted(zipFileName, zipFile.length());
                }
            }
        }
        long downloadEndTime = System.currentTimeMillis();
        log.info("Download End at {}, spent time {}", downloadEndTime, downloadEndTime - downloadStartTime);
        return true;
    }
}
