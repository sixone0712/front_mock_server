package jp.co.canon.ckbs.eec.service.command;

public class Pattern {
    String pattern;

    public Pattern(String pattern){


        this.pattern = pattern;
    }

    public boolean matches(String str){
        return str.matches(this.pattern);
    }
}
