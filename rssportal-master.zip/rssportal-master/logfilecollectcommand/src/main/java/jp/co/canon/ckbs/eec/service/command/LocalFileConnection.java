package jp.co.canon.ckbs.eec.service.command;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;

@Slf4j
public class LocalFileConnection extends FileConnection{

    File currentDir;
    static Calendar getFileTimestamp(File file){
        return toCalendar(file.lastModified());
    }

    @Override
    public boolean connect(Configuration configuration) {
        return true;
    }

    @Override
    public void disconnect() {

    }

    @Override
    public boolean changeDirectory(String directory) {
        currentDir = new File(directory);
        if (currentDir.exists() && currentDir.isDirectory()){
            return true;
        }
        return false;
    }

    @Override
    public LogFileInfo[] listFiles() {
        File[] files = currentDir.listFiles();
        ArrayList<LogFileInfo> logFileInfoArrayList = new ArrayList<>();
        for(File file : files){
            LogFileInfo info = new LogFileInfo(file.getName(), file.length(), getFileTimestamp(file), file.isFile());
            logFileInfoArrayList.add(info);
        }
        return logFileInfoArrayList.toArray(new LogFileInfo[0]);
    }

    @Override
    public InputStream getInputStream(String fileName) {
        log.info("retrive InputStream ({})", fileName);
        File file = new File(fileName);
        InputStream inputStream = null;

        try {
            inputStream = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            log.error("Exception : {}", e.getMessage());
        }
        return inputStream;
    }

    @Override
    public void completePendingCommand() {

    }
}
