package jp.co.canon.ckbs.eec.service.command;

import jp.co.canon.ckbs.eec.service.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.cli.*;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class GetCommand implements Command {

/*
    -url : download top url
        ex 1> ftp://192.168.0.22:22001/LOG/001
        ex 2> file://CANON/LOG

    -md : ftp mode (passive, active)

    -u : user and password for ftp
        ex> -u root/password

    -fl : file list file.
        ex> -fl aaaa.LST

    -dest : save destintation directory.
        ex> -dest /LOG/downloads/MPA_XXXX

    -az : zip after download
        ex> -az zipFileName

    -max_thread : max thread count
        ex> -max_thread 4

    -structure : preserve directory structure or not
        ex> -structure true
        ex> -structure false
 */
    String [] files;
    FileInfoQueue fileQueue = new FileInfoQueue();
    StopChecker stopChecker = new StopChecker();

    void loadFileList(String fileListFile, boolean preserveStructure) throws IOException {
        try {
            List<String> fileList = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(fileListFile))));
            String line;
            while( (line = reader.readLine()) != null){
                if (line.length() == 0){
                    continue;
                }
                String[] lineArr = line.split(",");
                if (lineArr.length == 0){
                    continue;
                }
                fileList.add(lineArr[0]);
                String fileName = lineArr[0];
                String downloadPath = fileName;
                if (!preserveStructure){
                    int slashIdx = downloadPath.lastIndexOf("/");
                    if (slashIdx >= 0){
                        downloadPath = downloadPath.substring(slashIdx+1);
                    }
                }
                fileQueue.push(new FileInfo(fileName, downloadPath));
            }
            files = fileList.toArray(new String[0]);
        } catch (FileNotFoundException e) {
            throw new IOException(e);
        }
    }

    @Override
    public void execute(String[] args) {
        Options options = new Options();
        options.addRequiredOption("url", "url", true, "");
        options.addRequiredOption("md", "md", true, "");
        options.addRequiredOption("u", "u", true, "");
        options.addRequiredOption("fl", "fl", true, "");
        options.addRequiredOption("dest", "dest", true, "");
        options.addOption("az", "az", true, "");
        options.addOption("max_thread", "max_thread", true, "");
        options.addOption("structure", "structure", true, "");

        CommandLineParser parser = new DefaultParser();
        try {
            Configuration configuration = new Configuration();
            CommandLine commandLine = parser.parse(options, args);

            String url = commandLine.getOptionValue("url");
            String md = commandLine.getOptionValue("md");
            configuration.setMode(md);

            String uStr = commandLine.getOptionValue("u");
            String[] strs = uStr.split("/");
            if (strs.length != 2){
                System.out.println(String.format("ERR: user is invalid (%s).", uStr));
                System.exit(-1);
                return;
            }
            String user = strs[0];
            String password = strs[1];

            String fileList = commandLine.getOptionValue("fl");
            String dest = commandLine.getOptionValue("dest");

            boolean zip = commandLine.hasOption("az");
            String zipFileName = null;
            if (zip){
                zipFileName = commandLine.getOptionValue("az");
            }

            int max_thread = 4;
            if (commandLine.hasOption("max_thread")){
                String maxThreadStr = commandLine.getOptionValue("max_thread");
                max_thread = Integer.parseInt(maxThreadStr);
            }

            boolean preserveStructure = false;
            if (commandLine.hasOption("structure")){
                String structureStr = commandLine.getOptionValue("structure");
                if (structureStr.equals("true")){
                    preserveStructure = true;
                }
            }

            StatusReporter statusReporter = new StatusReporter();

            boolean result = this.execute(url, md, user, password, fileList, dest, zip, zipFileName, max_thread, preserveStructure, new DownloadStatusCallback() {
                @Override
                public void downloadStart(String fileName) {

                }

                @Override
                public void downloadProgress(String fileName, long fileSize, long totalDownloadSize) {
                    statusReporter.println(String.format("DOWNLOAD_PROGRESS:%s;%d;%d", fileName, fileSize, totalDownloadSize));
                }

                @Override
                public void downloadCompleted(String fileName, long fileSize, long totalDownloadSize, String destFilePath) {
                    statusReporter.println(String.format("DOWNLOAD_COMPLETE:%s;%d;%d;%s", fileName, fileSize, totalDownloadSize, destFilePath));
                }

                @Override
                public void archiveCompleted(String archiveFileName, long fileSize) {
                    statusReporter.println(String.format("ARCHIVE:%s;%d", archiveFileName, fileSize));
                }
            });
            if (!result){
                System.exit(-1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public void stopDownload(){
        stopChecker.setStopped();
    }

    public boolean execute(String url,
                        String md,
                        String user,
                        String password,
                        String fileList,
                        String dest,
                        boolean zip,
                        String zipFileName,
                           int max_thread,
                           boolean preserveStructure,
                           DownloadStatusCallback callback){

        Configuration configuration = new Configuration();
        URI uri = null;
        try {
            uri = new URI(url);
            configuration.setScheme(uri.getScheme());
            configuration.setHost(uri.getHost());
            configuration.setPort(uri.getPort());
            configuration.setRootPath(uri.getPath());
        } catch (URISyntaxException e) {
            return false;
        }
        configuration.setMode(md);

        configuration.setUser(user);
        configuration.setPassword(password);
        try {
            loadFileList(fileList, preserveStructure);
        } catch (IOException e) {
            return false;
        }

        FileAccessor accessor = FileAccessorFactory.createInstance(configuration);
        boolean result = accessor.downloadFiles(fileQueue, dest, zip, zipFileName, max_thread, preserveStructure, stopChecker, callback);
        return result;
    }
}
