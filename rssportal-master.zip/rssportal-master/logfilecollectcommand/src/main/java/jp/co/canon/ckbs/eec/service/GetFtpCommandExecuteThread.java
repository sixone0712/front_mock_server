package jp.co.canon.ckbs.eec.service;
import jp.co.canon.ckbs.eec.service.command.DownloadInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import java.io.*;
import java.util.Timer;
import java.util.TimerTask;

@Slf4j
public class GetFtpCommandExecuteThread extends Thread{
    FtpServerInfo serverInfo;

    String rootDir;
    String directory;
    String downloadDirectory;

    FileInfoQueue fileQueue;

    String commandInfoString;

    int downloadedCount = 0;

    boolean exitWithError = false;

    DownloadStatusCallback callback;

    DownloadInfo downloadInfo;

    long total_readed = 0;

    StopChecker stopChecker;

    public GetFtpCommandExecuteThread(FtpServerInfo serverInfo,
                                      String rootDir,
                                      String directory,
                                      String downloadDirectory,
                                      FileInfoQueue fileQueue,
                                      DownloadInfo downloadInfo,
                                      StopChecker stopChecker,
                                      DownloadStatusCallback callback){
        this.serverInfo = serverInfo;
        this.rootDir = rootDir;
        this.directory = directory;
        this.downloadDirectory = downloadDirectory;
        this.fileQueue = fileQueue;

        commandInfoString = createCommandInfoString();
        this.downloadInfo = downloadInfo;
        this.stopChecker = stopChecker;
        this.callback = callback;
    }

    void downloadStart(String fileName){
        if (callback != null){
            callback.downloadStart(fileName);
        }
    }

    void downloadProgress(String fileName, long fileSize, long totalDownloadSize){
        if (callback != null){
            callback.downloadProgress(fileName, fileSize, totalDownloadSize);
        }
    }

    void downloadCompleted(String fileName, long fileSize, long totalDownloadSize, String destFilePath){
        if (callback != null){
            callback.downloadCompleted(fileName, fileSize, totalDownloadSize, destFilePath);
        }
    }

    public boolean isExitWithError(){
        return exitWithError;
    }

    String createCommandInfoString(){
        return String.format("(%s, %s, %d, %s, %s, %s, %s)", "get", serverInfo.host, serverInfo.port, serverInfo.ftpmode, this.rootDir, this.directory, this.downloadDirectory);
    }


    void applyFtpMode(FTPClient ftpClient){
        if (!serverInfo.ftpmode.equalsIgnoreCase("active")){
            ftpClient.enterLocalPassiveMode();
        }
    }

    FTPClient connectServer(){
        FTPClient ftpClient = new FTPClient();
        try {
            ftpClient.setControlKeepAliveTimeout(30);
            ftpClient.connect(serverInfo.host, serverInfo.port);
            if (!ftpClient.isConnected()){
                return null;
            }
            int replyCode = ftpClient.getReplyCode();
            if (!FTPReply.isPositiveCompletion(replyCode)){
                ftpClient.disconnect();
                return null;
            }
            boolean logined = ftpClient.login(serverInfo.user, serverInfo.password);
            if (!logined){
                ftpClient.disconnect();
                return null;
            }
        } catch (IOException e) {
            try {
                ftpClient.disconnect();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            return null;
        }
        applyFtpMode(ftpClient);
        return ftpClient;
    }

    boolean changeDirectory(FTPClient ftpClient){
        boolean moved = false;
        try {
            moved = ftpClient.changeWorkingDirectory(rootDir);
        } catch (IOException e) {
            return false;
        }
        if (!moved){
            return false;
        }
        if (directory == null){
            return true;
        }
        try {
            moved = ftpClient.changeWorkingDirectory(directory);
        } catch (IOException e) {
            return false;
        }
        return moved;
    }

    FileDownloadResult inputStreamToFile(InputStream inputStream, String fileName){
        downloadStart(fileName);
        File downloadDirectoryFile = new File(downloadDirectory);
        File outputFile = new File(downloadDirectoryFile, fileName);

        byte[] buffer = new byte[16384];
        total_readed = 0;
        int readed;
        Timer progressTimer = new Timer();
        progressTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                downloadProgress(fileName, total_readed, downloadInfo.getTotalDownloadSize());
            }
        }, 1000, 1000);

        try (OutputStream outputStream = new FileOutputStream(outputFile)){
            while ((readed = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, readed);
                total_readed += readed;
                downloadInfo.increaseDownloadSize(readed);
                Thread.yield();
            }
            downloadInfo.increaseDownloadCount();
            downloadCompleted(fileName, total_readed, downloadInfo.getTotalDownloadSize(), fileName);
            log.info("STATUS: download complete ({}, {}){}", fileName, total_readed, commandInfoString);
            if (total_readed == 0){
                return FileDownloadResult.RESULT_COMPLETED_SKIP_RECONNECT;
            }
            return FileDownloadResult.RESULT_COMPLETED;
        } catch (FileNotFoundException e) {
            log.error("ERR: inputStreamToFile FileNotFoundException...({})", commandInfoString);
            return FileDownloadResult.RESULT_FAIL;
        } catch (IOException e) {
            log.error("WARN: inputStreamToFile IOException ({}){} {}", fileName, commandInfoString, e.getMessage());
            log.error("WARN: download failed ({},{}){}", fileName, total_readed, commandInfoString);
            return FileDownloadResult.RESULT_RETRY_PERMANENT;
        } finally{
            progressTimer.cancel();
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    FileDownloadResult downloadFile(FTPClient ftpClient, String fileName){
        applyFtpMode(ftpClient);
        try {
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            ftpClient.setFileTransferMode(FTP.STREAM_TRANSFER_MODE);
        } catch (IOException e) {
            log.error("ERR: setFileType, setFileTransferMode Failed ({}){} {}", fileName, commandInfoString, e.getMessage());
            return FileDownloadResult.RESULT_FAIL;
        }

        try (InputStream inputStream = ftpClient.retrieveFileStream(fileName)){
            if (inputStream == null){
                int replyCode = ftpClient.getReplyCode();
                log.error("ERR:downloadFile inputStream == null({})({}){}", fileName, replyCode, commandInfoString);
                if (replyCode / 100 == 4){
                    return FileDownloadResult.RESULT_RETRY_TRANSIENT;
                }
                return FileDownloadResult.RESULT_RETRY_PERMANENT;
            }
            FileDownloadResult result;
            result = inputStreamToFile(inputStream, fileName);
            if (result == FileDownloadResult.RESULT_COMPLETED) {
                boolean completePendingCommand = false;
                try {
                    log.info("Start Complete Pending Command ({}){}", fileName, commandInfoString);
                    completePendingCommand = ftpClient.completePendingCommand();
                } catch (IOException e) {
                    log.error("IOException Compelete Pending Command({}){}", fileName, commandInfoString);
                }
                log.info("End Complete Pending Command({}){}", fileName, commandInfoString);
                if (!completePendingCommand) {
                    log.error("Complete Pending Command failed({}){}", fileName, commandInfoString);
                }
            }
            return result;
        } catch(IOException e){
            return FileDownloadResult.RESULT_RETRY_PERMANENT;
        }
    }

    @Override
    public void run() {
        FTPClient ftpClient = null;
        FileInfo fileInfo = fileQueue.poll();
        FileDownloadResult result;
        while(fileInfo != null && !stopChecker.isStopped()){
            if (ftpClient == null){
                ftpClient = connectServer();
                if (ftpClient == null){
                    this.exitWithError = true;
                    log.error("Cannot Connect to ftp server.");
                    break;
                }
                boolean moved = changeDirectory(ftpClient);
                if (!moved){
                    this.exitWithError = true;
                    log.error("ERR: Change Directory Failed({}){}", ftpClient.getReplyCode(), commandInfoString);
                    break;
                }
            }
            result = downloadFile(ftpClient, fileInfo.getFilename());
            if (result == FileDownloadResult.RESULT_COMPLETED_SKIP_RECONNECT){
                try {
                    log.error("SKIP Disconnect ({}){}", fileInfo.getFilename(), commandInfoString);
                    ftpClient.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ftpClient = null;
                fileInfo = fileQueue.poll();
                continue;
            }
            if (result == FileDownloadResult.RESULT_RETRY_PERMANENT){
                try {
                    log.error("Disconnect ({}){}", fileInfo.getFilename(), commandInfoString);
                    ftpClient.disconnect();
                } catch (IOException e) {
                }
                ftpClient = null;
                if (fileInfo.getRetryCount() < 5){
                    fileInfo.increaseRetryCount();
                    fileQueue.push(fileInfo);
                    fileInfo = fileQueue.poll();
                    continue;
                }
                result = FileDownloadResult.RESULT_FAIL;
                log.error("DOWNLOAD RETRY OVER({}){}", fileInfo.getFilename(), commandInfoString);
            }
            if (result == FileDownloadResult.RESULT_RETRY_TRANSIENT){
                try {
                    log.error("Disconnect ({}){}", fileInfo.getFilename(), commandInfoString);
                    ftpClient.disconnect();
                } catch (IOException e) {
                }
                ftpClient = null;
                fileQueue.push(fileInfo);
                fileInfo = fileQueue.poll();
                continue;
            }
            if (result == FileDownloadResult.RESULT_FAIL){
                this.exitWithError = true;
                log.error("DOWNLOAD FAILED.({}){}", fileInfo.getFilename(), commandInfoString);
                break;
            }
            downloadedCount++;
            fileInfo = fileQueue.poll();
        }
        if (this.exitWithError){
            stopChecker.setStopped();
        }
        if (ftpClient != null) {
            try {
                log.info("Disconnect FINAL. {}", commandInfoString);
                ftpClient.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
