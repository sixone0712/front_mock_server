package jp.co.canon.ckbs.eec.service.command;

import java.util.ArrayList;
import java.util.List;

public class RuleChecker {
    Pattern[] patterns = new Pattern[0];
    int count = 0;
    Pattern lastPattern = null;

    private RuleChecker(){

    }

    void applyPattern(String patternStr){
        List<Pattern> patternArray = new ArrayList<>();
        String[] patternArr = patternStr.split("/");

        count = 0;
        for(String patStr : patternArr){
            if (patStr.length() > 0) {
                if (patStr.equals("YYMMDD")){
                    patternArray.add(new Pattern("^20[0-9][0-9]"));
                    patternArray.add(new Pattern("^[01][0-9]"));
                    lastPattern = new Pattern("^[0-3][0-9]");
                    patternArray.add(lastPattern);
                } else if (patStr.equals("yyyymmddhhmmss") || patStr.equals("YYYYMMDDhhmmss")){
                    Pattern pattern = new Pattern("^20[0-9][0-9][01][0-9][0-3][0-9].+");
                    patternArray.add(pattern);
                    lastPattern = pattern;
                } else {
                    String convertedPatternStr = patStr.replace(".", "\\.")
                            .replace("*", ".+");
                    Pattern pattern = new Pattern(convertedPatternStr);
                    patternArray.add(pattern);
                    lastPattern = pattern;
                }
                count++;
            }
        }
        patterns = patternArray.toArray(new Pattern[0]);
    }

    public int getCount(){
        return count;
    }

    public Pattern getLastPattern(){
        return lastPattern;
    }

    public boolean matches(String str, int index){
        if (index >= count){
            return false;
        }
        return patterns[index].matches(str);
    }

    public static RuleChecker create(String patternStr){
        RuleChecker ruleChecker = new RuleChecker();

        ruleChecker.applyPattern(patternStr);

        return ruleChecker;
    }
}
