package jp.co.canon.ckbs.eec.service.command;

import jp.co.canon.ckbs.eec.service.FileInfo;
import jp.co.canon.ckbs.eec.service.FileInfoQueue;
import jp.co.canon.ckbs.eec.service.DownloadStatusCallback;
import jp.co.canon.ckbs.eec.service.StopChecker;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.Timer;
import java.util.TimerTask;

@Slf4j
public class GetCommandExecuteThread extends Thread{
    Configuration configuration;
    FileAccessor fileAccessor;
    FileInfoQueue fileQueue;
    boolean preserveDirStructure;
    String downloadDirectory;
    DownloadInfo downloadInfo;
    FileInfoQueue downloadedQueue;
    StopChecker stopChecker;
    DownloadStatusCallback callback;

    long total_readed = 0;

    boolean exitWithError = false;
    public GetCommandExecuteThread(Configuration configuration,
                                   FileAccessor fileAccessor,
                                   String downloadDirectory,
                                   FileInfoQueue fileQueue,
                                   boolean preserveStructure,
                                   DownloadInfo downloadInfo,
                                   FileInfoQueue downloadedQueue,
                                   StopChecker stopChecker,
                                   DownloadStatusCallback callback){
        this.configuration = configuration;
        this.fileAccessor = fileAccessor;
        this.downloadDirectory = downloadDirectory;
        this.fileQueue = fileQueue;
        this.preserveDirStructure = preserveStructure;
        this.downloadInfo = downloadInfo;
        this.downloadedQueue = downloadedQueue;
        this.stopChecker = stopChecker;
        this.callback = callback;
    }

    public boolean getExitWithError(){
        return exitWithError;
    }

    void downloadStart(String fileName){
        if (callback != null){
            callback.downloadStart(fileName);
        }
    }

    void downloadProgress(String fileName, long fileSize, long totalDownloadSize){
        if (callback != null){
            callback.downloadProgress(fileName, fileSize, totalDownloadSize);
        }
    }

    void downloadCompleted(String fileName, long fileSize, long totalDownloadSize, String destFilePath){
        if (callback != null){
            callback.downloadCompleted(fileName, fileSize, totalDownloadSize, destFilePath);
        }
    }

    boolean inputStreamToLocalFile(InputStream inputStream, String destFileName, String downloadPath) throws Exception{
        downloadStart(destFileName);
        String fileName = downloadPath;

        String pullPath = this.downloadDirectory + "/" + fileName;
        int slash = pullPath.lastIndexOf("/");
        String destDirStr = pullPath.substring(0, slash);
        File destDir =  new File(destDirStr);
        destDir.mkdirs();

        log.info("save InputStream to {}", pullPath);
        OutputStream outputStream = null;

        try {
            outputStream = new FileOutputStream(new File(pullPath));
        } catch (FileNotFoundException e) {
            return false;
        }
        byte[] buffer = new byte[8192];
        total_readed = 0;
        int readed;
        Timer progressTimer = new Timer();
        progressTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                downloadProgress(destFileName, total_readed, downloadInfo.getTotalDownloadSize());
            }
        }, 1000, 1000);

        try {
            while ((readed = inputStream.read(buffer)) > 0) {
                if (stopChecker.isStopped()){
                    throw new Exception("Stopped");
                }
                outputStream.write(buffer, 0, readed);
                total_readed += readed;
                downloadInfo.increaseDownloadSize(readed);
                Thread.yield();
            }
            downloadInfo.increaseDownloadCount();
            downloadCompleted(destFileName, total_readed, downloadInfo.getTotalDownloadSize(), fileName);
            return true;
        } catch(IOException e){

        } finally {
            progressTimer.cancel();
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    boolean downloadFile(FileConnection connection, FileInfo fileInfo) throws Exception{
        log.info("download file : {}", fileInfo.getFilename());
        String pullPath = configuration.rootPath + "/" + fileInfo.getFilename();

        InputStream inputStream = connection.getInputStream(pullPath);
        if (inputStream != null){
            boolean rc = inputStreamToLocalFile(inputStream, fileInfo.getFilename(), fileInfo.getDownloadPath());
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (this.total_readed > 0) {
                    connection.completePendingCommand();
                }
            }
            return rc;
        } else {
            return false;
        }
    }

    @Override
    public void run() {
        FileConnection connection = null;
        FileInfo fileInfo = fileQueue.poll();
        while(fileInfo != null){
            if (stopChecker.isStopped()){
                break;
            }
            if (connection == null) {
                connection = fileAccessor.createFileConnection();
                boolean connected = connection.connect(configuration);
                if (!connected){
                    exitWithError = true;
                    break;
                }
            }
            try {
                if (downloadFile(connection, fileInfo)) {
                    downloadedQueue.push(fileInfo);
                } else {
                    if (fileInfo.getRetryCount() < 3) {
                        fileInfo.increaseRetryCount();
                        fileQueue.push(fileInfo);
                    }
                    connection.disconnect();
                    connection = null;
                }
            } catch (Exception e){
                exitWithError = true;
                break;
            }
            fileInfo = fileQueue.poll();
        }
        if (connection != null){
            connection.disconnect();
        }
    }
}
