package jp.co.canon.ckbs.eec.service;

import jp.co.canon.ckbs.eec.service.command.GetCommand;
import jp.co.canon.ckbs.eec.service.command.ListCommand;

public class ServiceCommand {
    static Command createCommandFromName(String str){
        if (str.equals("list")){
            return new ListCommand();
        }
        if (str.equals("get")){
            return new GetCommand();
        }
        return null;
    }

    public static void main(String[] args){
        if (args.length < 1){
            System.out.println("Command Error");
            System.exit(-1);
            return;
        }
        Command command = createCommandFromName(args[0]);
        if (command == null){
            System.out.println("Invalid Command");
            System.exit(-1);
            return;
        }

        String[] newArgs = new String[args.length - 1];
        for(int idx = 1; idx < args.length; ++idx){
            newArgs[idx - 1] = args[idx];
        }

        command.execute(newArgs);
    }
}
