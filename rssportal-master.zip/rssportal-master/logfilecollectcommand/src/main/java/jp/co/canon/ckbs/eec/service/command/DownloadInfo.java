package jp.co.canon.ckbs.eec.service.command;

public class DownloadInfo {
    long totalDownloadSize = 0;
    long totalDownloadCount = 0;

    public synchronized void increaseDownloadCount(){
        totalDownloadCount++;
    }

    public synchronized void increaseDownloadSize(long size){
        totalDownloadSize += size;
    }

    public long getTotalDownloadSize(){
        return totalDownloadSize;
    }

    public long getTotalDownloadCount(){
        return totalDownloadCount;
    }
}
