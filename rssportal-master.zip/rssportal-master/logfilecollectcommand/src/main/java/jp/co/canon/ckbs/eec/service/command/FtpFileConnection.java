package jp.co.canon.ckbs.eec.service.command;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPConnectionClosedException;
import org.apache.commons.net.ftp.FTPFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

@Slf4j
public class FtpFileConnection extends FileConnection{
    FTPClient ftpClient = null;
    boolean passiveMode = true;

    @Override
    public boolean connect(Configuration configuration) {
        if (configuration.port == -1){
            configuration.port = 21;
        }
        log.info("host : {}", configuration.host);
        log.info("port : {}", configuration.port);
        log.info("mode : {}", configuration.mode);
        if (configuration.mode.equals("active")){
            passiveMode = false;
        }

        while (ftpClient == null) {
            ftpClient = new FTPClient();
            try {
                ftpClient.setControlKeepAliveTimeout(30);
                ftpClient.connect(configuration.host, configuration.port);
                boolean logined = ftpClient.login(configuration.user, configuration.password);
                if (!logined) {
                    log.info("login failed. {} {} {} {}", configuration.host, configuration.port, configuration.user, configuration.password);
                    ftpClient.disconnect();
                    ftpClient = null;
                    return false;
                }
            } catch (FTPConnectionClosedException e) {
                try {
                    ftpClient.disconnect();
                } catch (IOException ioException) {
                }
                ftpClient = null;
                log.error("login failed by FTPConnectionClosedException {} retry...", e.getMessage());
            } catch (IOException e){
                try {
                    ftpClient.disconnect();
                } catch (IOException ioException) {

                }
                ftpClient = null;
                log.error("login failed by exception {}", e.getMessage());
                return false;
            }
            Thread.yield();
        }
        log.info("login success. {} {} {} {}", configuration.host, configuration.port, configuration.user, configuration.password);
        return true;
    }

    @Override
    public void disconnect() {
        log.info("disconnect");
        try {
            ftpClient.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        ftpClient = null;
    }

    @Override
    public boolean changeDirectory(String directory) {
        log.info("changeDirectory({})", directory);
        try {
            boolean moved = ftpClient.changeWorkingDirectory(directory);
            if (!moved){
                log.error("changeDirectory({}) failed", directory);
            }
            return moved;
        } catch (IOException e) {
            log.error("changeDirectory({}) failed", directory);
            return false;
        }
    }

    void applyFtpMode(){
        if (passiveMode){
            ftpClient.enterLocalPassiveMode();
        } else {
            ftpClient.enterLocalActiveMode();
        }
    }

    @Override
    public LogFileInfo[] listFiles() {
        try {
            applyFtpMode();
            FTPFile[] files = ftpClient.listFiles();
            ArrayList<LogFileInfo> logFileInfoArrayList = new ArrayList<>();
            for(FTPFile file : files){
                LogFileInfo info = new LogFileInfo(file.getName(), file.getSize(), file.getTimestamp(), file.isFile());
                logFileInfoArrayList.add(info);
            }
            return logFileInfoArrayList.toArray(new LogFileInfo[0]);
        } catch (IOException e) {
            return new LogFileInfo[0];
        }
    }

    @Override
    public InputStream getInputStream(String fileName){
        applyFtpMode();
        InputStream inputStream = null;
        try {
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            ftpClient.setFileTransferMode(FTP.STREAM_TRANSFER_MODE);
            inputStream = ftpClient.retrieveFileStream(fileName);
        } catch (IOException e) {
            log.error("Exception : {}", e.getMessage());
        }
        if (inputStream == null){
            log.error("getInputStream({}) failed", fileName);
        } else {
            log.info("retrive InputStream success({})", fileName);
        }
        return inputStream;
    }

    @Override
    public void completePendingCommand(){
        try {
            ftpClient.completePendingCommand();
        } catch (IOException e) {
            log.error("Exception : {}", e.getMessage());
        }
    }

}
