package jp.co.canon.ckbs.eec.service;

public interface Command {
    void execute(String[] args);
}
