package jp.co.canon.ckbs.eec.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.cli.*;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import java.io.IOException;

@Slf4j
public class ListFtpCommand extends BaseFtpCommand {
    String rootDir;
    String destDir;

    String commandInfoString;

    String createCommandInfoString(){
        return String.format("(%s, %s, %d, %s, %s, %s)", "list", this.host, this.port, this.ftpmode, this.rootDir, this.destDir);
    }

    FTPFile[] listFiles() throws Exception{
        FTPClient ftpClient = new FTPClient();
        try {
            ftpClient.connect(host, port);
            boolean logined = ftpClient.login(user, password);
            if (!logined){
                log.error("ERR: LOGIN FAILED {}", commandInfoString);
                throw new Exception("Login Failed");
            }
            log.info("STATUS:LOGIN_OK {}" + commandInfoString);

            boolean moved = true;
            moved = ftpClient.changeWorkingDirectory(rootDir);
            if (!moved){
                log.error("ERR: DIRECTORY MOVE FAILED(ROOT DIR) {}", commandInfoString);
                throw new Exception("Change Directory Failed");
            }
            moved = ftpClient.changeWorkingDirectory(destDir);
            if (!moved){
                log.error("ERR: DIRECTORY MOVE FAILED(DEST DIR) {}", commandInfoString);
                throw new Exception("Change Directory Failed");
            }
            if (!ftpmode.equalsIgnoreCase("active")){
                ftpClient.enterLocalPassiveMode();
                log.info("STATUS:ENTER PASSIVE {}", commandInfoString);
            }
            FTPFile[] ftpFiles = ftpClient.listFiles();
            log.info("END TOTAL: {} {}", ftpFiles.length, commandInfoString);
            return ftpFiles;
        } catch (IOException e) {
            log.error("ERR: IOEXCEPTION {}", commandInfoString);
            throw e;
        } catch (Exception e){
            throw e;
        } finally {
            if (ftpClient.isConnected()) {
                try {
                    ftpClient.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    void doCommand(){
        try {
            FTPFile[] ftpFiles = listFiles();
            for(FTPFile file : ftpFiles){
                if (file.isDirectory()) {
                    System.out.println("DIRECTORY:"+file.getName());
                } else {
                    System.out.println("FILE:"+file.getName()+";"+file.getSize());
                }
            }
            System.out.println("END TOTAL:" + ftpFiles.length);
        } catch(Exception e){
            System.out.println("ERR: Exception on listFiles..");
        }
    }

    @Override
    public void execute(String[] args) {
        Options options = new Options();

        options.addRequiredOption("host", "host", true, "ftp host");
        options.addRequiredOption("port", "port", true, "ftp port");
        options.addRequiredOption("md", "md", true, "ftp mode");
        options.addRequiredOption("u", "user", true, "user id and password( -u user/password)");
        options.addRequiredOption("root", "root", true, "ftp root directory");
        options.addRequiredOption("dest", "dest", true, "destination directory");

        CommandLineParser parser = new DefaultParser();

        CommandLine commandLine = null;
        try {
            commandLine = parser.parse(options, args, true);
            String userStr = commandLine.getOptionValue("u");
            this.host = commandLine.getOptionValue("host");
            String portStr = commandLine.getOptionValue("port");
            this.port = Integer.parseInt(portStr);
            this.ftpmode = commandLine.getOptionValue("md");
            String[] userStrArr = userStr.split("/");
            String user = userStrArr[0];
            String password = userStrArr[1];
            this.user = user;
            this.password = password;

            this.rootDir = commandLine.getOptionValue("root");
            this.destDir = commandLine.getOptionValue("dest");

            this.commandInfoString = createCommandInfoString();
            doCommand();
        } catch (ParseException e) {
            System.out.println("ERR: Command Parse Exception");
            log.error("ERR: Command Parse Exception");
            e.printStackTrace();
        }
    }

    public FTPFile[] execute(String host,
                             int port,
                             String ftpmode,
                             String user,
                             String password,
                             String rootDir,
                             String destDir){
        this.host = host;
        this.port = port;
        this.ftpmode = ftpmode;
        this.user = user;
        this.password = password;
        this.rootDir = rootDir;
        this.destDir = destDir;

        this.commandInfoString = createCommandInfoString();
        try {
            return listFiles();
        }catch (Exception e){
            return new FTPFile[0];
        }
    }
}
