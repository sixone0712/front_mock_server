package jp.co.canon.ckbs.eec.service;

public class FtpServerInfo {
    String host;
    int port;
    String ftpmode;
    String user;
    String password;
}
