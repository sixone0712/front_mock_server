package jp.co.canon.ckbs.eec.service;

import org.junit.jupiter.api.Test;

public class FileDownloadResultTest {
    @Test
    void test_001(){
        FileDownloadResult r = FileDownloadResult.RESULT_NONE;
    }
}
