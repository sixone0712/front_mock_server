package jp.co.canon.ckbs.eec.service;

import org.junit.jupiter.api.Test;

public class StatusReporterTest {
    @Test
    void test_001(){
        StatusReporter statusReporter = new StatusReporter();
        statusReporter.reportStatus("NORMAL STATUS");
    }
}
