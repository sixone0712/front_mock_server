package jp.co.canon.ckbs.eec.fs.manage.service;

import jp.co.canon.ckbs.eec.fs.configuration.Category;
import lombok.Getter;
import lombok.Setter;

public class CategoryList {
    @Getter @Setter
    Category[] categories;
}
