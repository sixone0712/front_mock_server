package jp.co.canon.ckbs.eec.fs.manage.service.configuration;

import lombok.Getter;
import lombok.Setter;

public class Machine {
    @Getter @Setter
    String machineName;

    @Getter @Setter
    String host;

    @Getter @Setter
    String ots;

    @Getter @Setter
    String line;

    @Getter @Setter
    String ftpUser;

    @Getter @Setter
    String ftpPassword;

    @Getter @Setter
    String vftpUser;

    @Getter @Setter
    String vftpPassword;

    @Getter @Setter
    String serialNumber;

    @Getter @Setter
    String toolType;

    @Getter @Setter
    int port;

    public Machine(){

    }

    public Machine(String machineName,
                   String host,
                   String ots,
                   String line,
                   String ftpUser,
                   String ftpPassword,
                   String vftpUser,
                   String vftpPassword,
                   String serialNumber,
                   String toolType,
                   int port) {
        this.machineName = machineName;
        this.host = host;
        this.ots = ots;
        this.line = line;
        this.ftpUser = ftpUser;
        this.ftpPassword = ftpPassword;
        this.vftpUser = vftpUser;
        this.vftpPassword = vftpPassword;
        this.serialNumber = serialNumber;
        this.toolType = toolType;
        this.port = port;
    }
}
