package jp.co.canon.ckbs.eec.fs.manage.service.configuration.structure;

import lombok.Getter;
import lombok.Setter;

public class MpaInfoEx {
    @Getter @Setter
    MpaInfo mpa;
    @Getter @Setter
    OtsInfo ots;
}
