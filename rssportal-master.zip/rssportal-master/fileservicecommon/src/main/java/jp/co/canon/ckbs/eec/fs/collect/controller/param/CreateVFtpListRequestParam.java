package jp.co.canon.ckbs.eec.fs.collect.controller.param;

import lombok.Getter;
import lombok.Setter;

public class CreateVFtpListRequestParam {
    @Getter @Setter
    String directory;
}
