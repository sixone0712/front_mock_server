package jp.co.canon.ckbs.eec.fs.configuration.legacy.constructioninfo;

import org.junit.jupiter.api.Test;

public class FabTest {
    @Test
    void test_001(){
        Fab fab = new Fab();
        fab.getMachineList();
    }
}
