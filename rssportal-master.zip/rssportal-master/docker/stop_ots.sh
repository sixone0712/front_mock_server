docker container stop Proxy FileServiceCollect ServiceManager
docker container rm Proxy FileServiceCollect ServiceManager

