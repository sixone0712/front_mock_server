docker container stop Proxy Database Rapid-Collector ServiceManager
docker container rm Proxy Database Rapid-Collector ServiceManager

