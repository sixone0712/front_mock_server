package jp.co.canon.ckbs.eec.fs.collect;

import jp.co.canon.ckbs.eec.fs.collect.controller.param.*;
import jp.co.canon.ckbs.eec.fs.collect.service.LogFileList;
import jp.co.canon.ckbs.eec.fs.manage.service.configuration.ConfigurationService;
import jp.co.canon.ckbs.eec.fs.manage.service.configuration.category.CategoryInfo;
import jp.co.canon.ckbs.eec.fs.manage.service.configuration.structure.MpaInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
public class DefaultFileServiceCollectConnector implements FileServiceCollectConnector{
    ConfigurationService configurationService;
    RestTemplate restTemplate;
    String host;
    String prefix;

    public DefaultFileServiceCollectConnector(String host, RestTemplate restTemplate, ConfigurationService configurationService){
        this.configurationService = configurationService;
        this.restTemplate = restTemplate;
        this.host = host;
        this.prefix = String.format("http://%s", this.host);
    }

    /*
    FTP INTERFACE
    */
    String generateFtpHostUrl(MpaInfo mpaInfo, CategoryInfo categoryInfo){
        return String.format("ftp://%s:%d%s", mpaInfo.getHost(), categoryInfo.getPort(), categoryInfo.getRootDir());
    }

    public LogFileList getFtpFileList(String machine,
                                      String category,
                                      String from,
                                      String to,
                                      String keyword,
                                      String path){
        MpaInfo mpaInfo = configurationService.getMpaInfo(machine);
        CategoryInfo categoryInfo = configurationService.getCategory(category);

        FscListFilesRequestParam param = new FscListFilesRequestParam();
        param.setMachine(machine);
        param.setCategory(category);
        param.setFrom(from);
        param.setTo(to);
        param.setKeyword(keyword);
        param.setPath(path);

        param.setHost(generateFtpHostUrl(mpaInfo, categoryInfo));
        String pattern;
        if (categoryInfo.getPatternDir().endsWith("/")){
            pattern = categoryInfo.getPatternDir() + categoryInfo.getFileName();
        } else {
            pattern = String.format("%s/%s", categoryInfo.getPatternDir(), categoryInfo.getFileName());
        }
        param.setPattern(pattern);
        if (categoryInfo.getPort() == 21) {
            param.setUser(mpaInfo.getFtpUser());
            param.setPassword(mpaInfo.getFtpPassword());
        } else {
            param.setUser(mpaInfo.getVftpUser());
            param.setPassword(mpaInfo.getVftpPassword());
        }

        String url = this.prefix + "/fsc/ftp/files";
        try {
            ResponseEntity<LogFileList> res =
                    restTemplate.postForEntity(url, param, LogFileList.class);
            return res.getBody();
        } catch (RestClientException e){
            log.error("getFtpFileList RestClientException occurred ({})", e.getMessage());
            LogFileList logFileList = new LogFileList();
            logFileList.setErrorCode("500 RestClientException");
            logFileList.setErrorMessage(e.getMessage());
            return logFileList;
        }
    }

    FtpDownloadRequestResponse createFtpDownloadRequest(String machine, FscCreateFtpDownloadRequestParam param){
        String url = this.prefix + "/fsc/ftp/download";
        try {
            ResponseEntity<FtpDownloadRequestResponse> res =
                    restTemplate.postForEntity(url, param, FtpDownloadRequestResponse.class);
            return res.getBody();
        } catch (RestClientException e){
            log.error("createFtpDownloadRequest RestClientException occurred ({})", e.getMessage());
            FtpDownloadRequestResponse response = new FtpDownloadRequestResponse();
            response.setErrorCode("500 RestClientException");
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public FtpDownloadRequestResponse createFtpDownloadRequest(String machine, String category, boolean archive, String[] fileList){
        MpaInfo mpaInfo = configurationService.getMpaInfo(machine);
        CategoryInfo categoryInfo = configurationService.getCategory(category);

        FscCreateFtpDownloadRequestParam param = new FscCreateFtpDownloadRequestParam();
        param.setMachine(machine);
        param.setCategory(category);
        param.setArchive(archive);
        param.setFileList(fileList);

        param.setHost(generateFtpHostUrl(mpaInfo, categoryInfo));
        if (categoryInfo.getPort() == 21) {
            param.setUser(mpaInfo.getFtpUser());
            param.setPassword(mpaInfo.getFtpPassword());
        } else {
            param.setUser(mpaInfo.getVftpUser());
            param.setPassword(mpaInfo.getVftpPassword());
        }

        return createFtpDownloadRequest(machine, param);
    }

    public FtpDownloadRequestListResponse getFtpDownloadRequestList(String machine, String requestNo){
        String url = this.prefix + "/fsc/ftp/download/{requestNo}";
        try {
            ResponseEntity<FtpDownloadRequestListResponse> res =
                    restTemplate.getForEntity(url, FtpDownloadRequestListResponse.class, requestNo);

            return res.getBody();
        } catch (RestClientException e){
            log.error("getFtpDownloadRequestList RestClientException occurred ({})", e.getMessage());
            FtpDownloadRequestListResponse response = new FtpDownloadRequestListResponse();
            response.setErrorCode("500 RestClientException");
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public void cancelAndDeleteRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/ftp/download/{requestNo}";
        try {
            restTemplate.delete(url, requestNo);
        } catch (RestClientException e){
            log.error("cancelAndDeleteRequest RestClientException occurred ({})", e.getMessage());
            e.printStackTrace();
        }
    }

    /*
        VFTP INTERFACE
     */

    /* SSS LIST */
    public VFtpSssListRequestResponse createVFtpSssListRequest(String machine, String directory) {
        MpaInfo mpaInfo = configurationService.getMpaInfo(machine);
        String url = this.prefix + "/fsc/vftp/sss/list";

        FscCreateVFtpListRequestParam param = new FscCreateVFtpListRequestParam();
        param.setMachine(machine);
        param.setDirectory(directory);
        param.setHost(mpaInfo.getHost());
        param.setUser(mpaInfo.getVftpUser());
        param.setPassword(mpaInfo.getVftpPassword());
        try {
            ResponseEntity<VFtpSssListRequestResponse> res =
                    restTemplate.postForEntity(url, param, VFtpSssListRequestResponse.class, machine);

            return res.getBody();
        } catch (RestClientException e){
            log.error("createVFtpSssListRequest RestClientException occurred ({})", e.getMessage());
            VFtpSssListRequestResponse response = new VFtpSssListRequestResponse();
            response.setErrorCode(500);
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public VFtpSssListRequestResponse getVFtpSssListRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/vftp/sss/list/{requestNo}";
        try {
            ResponseEntity<VFtpSssListRequestResponse> res =
                    restTemplate.getForEntity(url, VFtpSssListRequestResponse.class, requestNo);

            return res.getBody();
        } catch (RestClientException e){
            log.error("getVFtpSssListRequest RestClientException occurred ({})", e.getMessage());
            VFtpSssListRequestResponse response = new VFtpSssListRequestResponse();
            response.setErrorCode(500);
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public void cancelAndDeleteVFtpSssListRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/vftp/sss/list/{requestNo}";
        try {
            restTemplate.delete(url, requestNo);
        } catch (RestClientException e){
            log.error("cancelAndDeleteVFtpSssListRequest RestClientException occurred ({})", e.getMessage());
            e.printStackTrace();
        }
    }

    /* SSS DOWNLOAD */
    public VFtpSssDownloadRequestResponse createVFtpSssDownloadRequest(String machine, String directory, String[] fileList, boolean archive){
        MpaInfo mpaInfo = configurationService.getMpaInfo(machine);
        String url = this.prefix + "/fsc/vftp/sss/download";

        FscCreateVFtpSssDownloadRequestParam param = new FscCreateVFtpSssDownloadRequestParam();
        param.setDirectory(directory);
        param.setFileList(fileList);
        param.setArchive(archive);
        param.setMachine(machine);
        param.setHost(mpaInfo.getHost());
        param.setUser(mpaInfo.getVftpUser());
        param.setPassword(mpaInfo.getVftpPassword());
        try {
            ResponseEntity<VFtpSssDownloadRequestResponse> res =
                    restTemplate.postForEntity(url, param, VFtpSssDownloadRequestResponse.class);

            return res.getBody();
        } catch (RestClientException e){
            log.error("createVFtpSssDownloadRequest RestClientException occurred ({})", e.getMessage());
            VFtpSssDownloadRequestResponse response = new VFtpSssDownloadRequestResponse();
            response.setErrorCode(500);
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public VFtpSssDownloadRequestResponse getVFtpSssDownloadRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/vftp/sss/download/{requestNo}";

        try {
            ResponseEntity<VFtpSssDownloadRequestResponse> res =
                    restTemplate.getForEntity(url, VFtpSssDownloadRequestResponse.class, requestNo);

            return res.getBody();
        } catch (RestClientException e){
            log.error("getVFtpSssDownloadRequest RestClientException occurred ({})", e.getMessage());
            VFtpSssDownloadRequestResponse response = new VFtpSssDownloadRequestResponse();
            response.setErrorCode(500);
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public void cancelAndDeleteVFtpSssDownloadRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/vftp/sss/download/{requestNo}";
        try {
            restTemplate.delete(url, requestNo);
        } catch (RestClientException e){
            log.error("getVFtpSssDownloadRequest RestClientException occurred ({})", e.getMessage());
            e.printStackTrace();
        }
    }

    /* COMPAT DOWNLOAD */
    public VFtpCompatDownloadRequestResponse createVFtpCompatDownloadRequest(String machine, String filename, boolean archive){
        MpaInfo mpaInfo = configurationService.getMpaInfo(machine);
        String url = this.prefix + "/fsc/vftp/compat/download";

        FscCreateVFtpCompatDownloadRequestParam param = new FscCreateVFtpCompatDownloadRequestParam();
        param.setFilename(filename);
        param.setArchive(archive);
        param.setMachine(machine);
        param.setHost(mpaInfo.getHost());
        param.setUser(mpaInfo.getVftpUser());
        param.setPassword(mpaInfo.getVftpPassword());
        try {
            ResponseEntity<VFtpCompatDownloadRequestResponse> res =
                    restTemplate.postForEntity(url, param, VFtpCompatDownloadRequestResponse.class);

            return res.getBody();
        } catch (RestClientException e){
            log.error("createVFtpCompatDownloadRequest RestClientException occurred ({})", e.getMessage());
            VFtpCompatDownloadRequestResponse response = new VFtpCompatDownloadRequestResponse();
            response.setErrorCode(500);
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public VFtpCompatDownloadRequestResponse getVFtpCompatDownloadRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/vftp/compat/download/{requestNo}";
        try {
            ResponseEntity<VFtpCompatDownloadRequestResponse> res =
                    restTemplate.getForEntity(url, VFtpCompatDownloadRequestResponse.class, requestNo);

            return res.getBody();
        } catch (RestClientException e){
            log.error("getVFtpCompatDownloadRequest RestClientException occurred ({})", e.getMessage());
            VFtpCompatDownloadRequestResponse response = new VFtpCompatDownloadRequestResponse();
            response.setErrorCode(500);
            response.setErrorMessage(e.getMessage());
            return response;
        }
    }

    public void cancelAndDeleteVFtpCompatDownloadRequest(String machine, String requestNo){
        String url = this.prefix + "/fsc/vftp/compat/download/{requestNo}";
        try {
            restTemplate.delete(url, requestNo);
        } catch (RestClientException e){
            log.error("cancelAndDeleteVFtpCompatDownloadRequest RestClientException occurred ({})", e.getMessage());
            e.printStackTrace();
        }
    }
}
